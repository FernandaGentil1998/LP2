
package SubLP;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class AppFileOutputstream {
    /*
    public static void main (String [] Args) throws FileNotFoundException, IOException{
        FileOutputStream fos = new FileOutputStream ("arquivoEscrever.txt");
        fos.write(111);
        fos.close();        
    }
    */
}
