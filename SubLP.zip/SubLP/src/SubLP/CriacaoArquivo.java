
package SubLP;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;

public class CriacaoArquivo {
    /*
    public static void main(String [] Args) throws FileNotFoundException, IOException{
        PrintWriter pw;
        try{
            pw = new PrintWriter("cria1.txt");
            pw.println("será?");
            pw.flush();
            pw.close();
        }catch (FileNotFoundException ex) {
            ex.printStackTrace();
        }
    }
*/
}
