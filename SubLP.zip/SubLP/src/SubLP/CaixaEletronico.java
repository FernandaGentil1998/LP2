
package SubLP;

public class CaixaEletronico {
    /*
    public static int [] sortear(){
        int [] vetor = {1,2,3,4,5,6,7,8,9};
        for(int i=0; i<vetor.length;i++){
            int indiceSorteado = i+(int)(Math.random()*(vetor.length-i));
            int aux = vetor[i];
            vetor[i] = vetor[indiceSorteado];
            vetor[indiceSorteado] = aux;
        }
        return vetor;
    }
*/
}
