
package SubLP;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class AppFileReader {
    /*
    public static void main (String [] Args) throws FileNotFoundException, IOException{
        FileReader fr = new FileReader("arquivoLer.txt");
        char[] cbuf = new char [100];
        fr.read(cbuf);
        System.out.println(cbuf);
        fr.close();
    }   
*/
}
