
package SubLP;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;

public class AppInputStreamReader {
    /*
    public static void main(String [] Args) throws FileNotFoundException, IOException{
        FileInputStream fis = new FileInputStream("cria1.txt");
        InputStreamReader isr = new InputStreamReader (fis);
        char[]cbuf = new char [100];
        isr.read(cbuf);
        System.out.println(cbuf);
        isr.close();
    }
*/
}
