
package SubLP;

public class POO {
    /*
   public static void main (String [] Args){
       Ponto p = new Ponto (3,4);
       retangulos r = new retangulos(6,8);
   }

    private static class retangulos {
        public retangulos(Ponto p, int altura, int largura) {
           ponto = p;
        }
        private Ponto ponto;
        private int altura, largura;
        public Ponto getPonto(){
            return ponto;
        }
        public int getAltura(){
            return altura;
        }
        public int getLargura(){
            return largura;
        }
        public String toString (){
            return "Retangulo";
        }
    }
    public class Ponto ()static {
        private int x,y;
        public POO (int x, int y){
            this.x = x;
            this.y = y;
        }
        public int getx(){
            return x;
        }
        public int gety(){
            return y;
        }
        public String toString(){
            return Ponto;
        }
    }
*/
}
