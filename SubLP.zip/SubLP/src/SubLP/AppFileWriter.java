
package SubLP;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;

public class AppFileWriter {
    /*
    public static void main (String [] Args)throws FileNotFoundException, IOException{
        FileWriter fw = new FileWriter ("arquivoEscrever.txt");
        fw.write('O');
        fw.write('L');
        fw.write('A');
        fw.close();
    }
*/
}
