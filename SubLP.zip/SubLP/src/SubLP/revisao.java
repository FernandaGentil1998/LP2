
package SubLP;

import java.util.Random;
import java.util.Scanner;
//Exercicio 12
public class revisao {
    /*
    public static void main (String [] Args){
        Random megaSena = new Random();
        for (int i=0; i<60; i++){
            System.out.println(megaSena.nextInt());
        }
    }
    //Exercicio 13
    public void gerarVetor (int itens){
        int v[] = new int[itens];
        Random megaSena = new Random();
        for (int i=itens; i<60; i++){
            megaSena.nextInt();
        }
    }
    //Exerciico 14
    public void imprimirVetor(){
        Scanner sc = new Scanner(System.in);
        int indice;
        int imprimir = 0;
        int i = sc.nextInt();
        int v [] = new int[i];
        for (indice=0;indice<v.length;indice++){
            v[indice] = sc.nextInt();
            imprimir = v[indice];
        }
        System.out.println(imprimir);
    }
    //Exercicio 15
    public void imprimirVetorInvertido(){
        //estrutura de dados    
    }
*/
}
