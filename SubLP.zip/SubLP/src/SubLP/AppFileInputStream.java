
package SubLP;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class AppFileInputStream {
    /*
    public static void main (String [] Args) throws FileNotFoundException, IOException{
        FileInputStream fis = new FileInputStream("arquivoLer.txt");
        int leitura = fis.read();
        System.out.println("1°" + leitura);
        leitura = fis.read();
        fis.close();
    }
*/
}

